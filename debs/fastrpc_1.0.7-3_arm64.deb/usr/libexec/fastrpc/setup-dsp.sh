#!/bin/bash

setup_soc_id()
{
    local SOC="$1"
    if [[ ! -f /tmp/fake-soc0/soc_id ]]; then
        mkdir -p /tmp/fake-soc0
        echo "$SOC" > /tmp/fake-soc0/soc_id
        mount --bind /tmp/fake-soc0/soc_id /sys/devices/soc0/soc_id
    fi
}

rm -rf /usr/lib/dsp

MAC=$(cat /sys/firmware/devicetree/base/model)

case "$MAC" in
    "Radxa CM-Q64"*)
        ln -sf /usr/share/qcom/qcs6490/radxa/cm-q64/dsp /usr/lib/dsp
        ;;
    "Radxa Dragon Q6A")
        ln -sf /usr/share/qcom/qcs6490/radxa/dragon-q6a/dsp /usr/lib/dsp
        ;;
    "Radxa Dragon Q6B")
        ln -sf /usr/share/qcom/qcs6490/radxa/dragon-q6b/dsp /usr/lib/dsp
        ;;
    "Radxa Dragon Q8B")
        ln -sf /usr/share/qcom/sc8280xp/radxa/dragon-q8b/dsp /usr/lib/dsp
        setup_soc_id 460
        ;;
    "Radxa DragonBay 4 Pro")
        ln -sf /usr/share/qcom/sc8280xp/radxa/dragonbay-4-pro/dsp /usr/lib/dsp
        setup_soc_id 460
        ;;
    "Radxa DragonStation 6")
        ln -sf /usr/share/qcom/sc8280xp/radxa/dragonstation-6/dsp /usr/lib/dsp
        setup_soc_id 460
        ;;
    "Radxa AIRbox Q900")
        ln -sf /usr/share/qcom/qcs9075/radxa/airbox-q900/dsp /usr/lib/dsp
        ;;
    "Radxa VMARC-Q9075 IO")
        ln -sf /usr/share/qcom/qcs9075/radxa/vmarc-q9075-io/dsp /usr/lib/dsp
        ;;
    *)
        echo "Unsupported board: $MAC"
        ;;
esac
